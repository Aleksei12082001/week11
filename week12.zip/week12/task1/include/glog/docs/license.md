# The 3-Clause BSD License

--8<-- "LICENSE.md"
